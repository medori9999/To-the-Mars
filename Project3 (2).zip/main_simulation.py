import asyncio
import logging
import random
import time
import json
from sqlalchemy.orm import Session
from sqlalchemy import desc
from database import SessionLocal, DBAgent, DBNews, DBCompany, DBTrade
from market_engine import MarketEngine
from community_manager import post_comment  # [추가됨 1] 댓글 기능 불러오기
from domain_models import Order, OrderSide, OrderType, AgentState
from agent_society_brain import agent_society_think

# ------------------------------------------------------------------
# 0. 로깅 및 엔진 설정
# ------------------------------------------------------------------
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
logger = logging.getLogger("GlobalMarket")

market_engine = MarketEngine()

# ------------------------------------------------------------------
# 1. 마켓 메이커 (Market Maker) - 유동성 공급자
# ------------------------------------------------------------------
def run_global_market_maker(db: Session, all_tickers: list):
    """
    모든 종목에 대해 매수/매도 호가를 깔아주는 역할 (거래 상대방)
    """
    mm_id = "MARKET_MAKER"
    mm_agent = db.query(DBAgent).filter(DBAgent.agent_id == mm_id).first()
    
    # MM이 없으면 생성 (돈은 무한대 1,000조 설정)
    if not mm_agent:
        initial_portfolio = {ticker: 1000000 for ticker in all_tickers}
        mm_agent = DBAgent(agent_id=mm_id, cash_balance=1e15, portfolio=initial_portfolio, psychology={})
        db.add(mm_agent)
        db.commit()

    for ticker in all_tickers:
        company = db.query(DBCompany).filter(DBCompany.ticker == ticker).first()
        if not company: continue

        curr_price = int(company.current_price)
        
        # 스프레드 설정 (현재가의 0.5% 위아래로 호가 제출)
        spread = max(1, int(curr_price * 0.005)) 
        qty = random.randint(50, 100) # 유동성 물량

        try:
            # MM의 지정가 주문 (Passive Order)
            market_engine.place_order(db, Order(agent_id=mm_id, ticker=ticker, side=OrderSide.BUY, order_type=OrderType.LIMIT, quantity=qty, price=curr_price - spread))
            market_engine.place_order(db, Order(agent_id=mm_id, ticker=ticker, side=OrderSide.SELL, order_type=OrderType.LIMIT, quantity=qty, price=curr_price + spread))
        except: pass

# ------------------------------------------------------------------
# [Helper] 시장 분위기(Social Interaction) 분석
# ------------------------------------------------------------------
def analyze_market_sentiment(db: Session, ticker: str):
    """
    최근 거래 내역을 분석하여 매수/매도 우위를 판단
    """
    trades = db.query(DBTrade).filter(DBTrade.ticker == ticker).order_by(desc(DBTrade.timestamp)).limit(20).all()
    if not trades:
        return "정보 없음 (탐색 단계)"
    
    start_p = trades[-1].price
    end_p = trades[0].price
    
    if end_p > start_p * 1.02: return "🔥 강력한 매수세 (불장)"
    elif end_p > start_p: return "📈 완만한 상승세"
    elif end_p < start_p * 0.98: return "😱 투매 발생 (공포장)"
    elif end_p < start_p: return "📉 하락세"
    else: return "⚖️ 눈치보기 (보합세)"

# ------------------------------------------------------------------
# 2. 에이전트 거래 실행 (Aggressive Taker Logic 적용)
# ------------------------------------------------------------------
async def run_agent_trade(agent_id: str, ticker: str):
    with SessionLocal() as db:
        try:
            agent = db.query(DBAgent).filter(DBAgent.agent_id == agent_id).first()
            company = db.query(DBCompany).filter(DBCompany.ticker == ticker).first()
            if not agent or not company: return

            # --- [Step 1] 정보 수집 ---
            news_obj = db.query(DBNews).filter(DBNews.company_name == company.name).order_by(desc(DBNews.id)).first()
            news_text = news_obj.title if news_obj else "특이사항 없음"
            market_sentiment = analyze_market_sentiment(db, ticker)

            # 기억 복원
            portfolio_qty = agent.portfolio.get(ticker, 0)
            avg_price = agent.psychology.get(f"avg_price_{ticker}", 0)
            if portfolio_qty > 0 and avg_price == 0: avg_price = company.current_price
            last_thought = agent.psychology.get(f"last_thought_{ticker}", None)

            # --- [Step 2] 뇌 가동 (의사결정) ---
            decision = await agent_society_think(
                agent_name=agent.agent_id, 
                agent_state=AgentState(**agent.psychology),
                context_info=news_text, 
                current_price=company.current_price, 
                cash=agent.cash_balance,
                portfolio_qty=portfolio_qty,
                avg_price=avg_price,
                last_action_desc=last_thought,
                market_sentiment=market_sentiment
            )
            
            # --- [Step 3] 행동 결정 ---
            action = decision.get("action", "HOLD").upper()
            qty = int(decision.get("quantity", 0))
            # AI가 원래 생각했던 '적정 가격'
            ai_target_price = int(decision.get("price", company.current_price)) 
            thought = decision.get("thought_process", "생각 없음")

            # 주문 유형 결정 (시장가 vs 지정가)
            is_market_order = random.random() < 0.7 
            
            curr_p = company.current_price
            final_price = ai_target_price
            order_desc = "지정가"

            if action == "BUY":
                if is_market_order:
                    final_price = int(curr_p * 1.02)
                    order_desc = "시장가(돌파)"
                else:
                    final_price = min(ai_target_price, int(curr_p * 0.99))
            
            elif action == "SELL":
                if is_market_order:
                    final_price = int(curr_p * 0.98)
                    order_desc = "시장가(투매)"
                else:
                    final_price = max(ai_target_price, int(curr_p * 1.01))
            
            else:
                pass

            # --- [Step 4] 기억 저장 ---
            new_psychology = dict(agent.psychology)
            new_psychology[f"last_thought_{ticker}"] = f"{action} ({order_desc}) 선택: {thought}"
            
            if action == "BUY" and qty > 0 and is_market_order:
                old_total = portfolio_qty * avg_price
                new_total = qty * final_price
                new_avg = (old_total + new_total) / (portfolio_qty + qty)
                new_psychology[f"avg_price_{ticker}"] = new_avg

            agent.psychology = new_psychology
            db.commit()

            # --- [Step 5] 주문 제출 ---
            if action in ["BUY", "SELL"] and qty > 0:
                side = OrderSide.BUY if action == "BUY" else OrderSide.SELL
                
                order = Order(
                    agent_id=agent.agent_id, ticker=ticker, side=side,
                    order_type=OrderType.LIMIT, quantity=qty, price=final_price
                )
                
                result = market_engine.place_order(db, order)
                
                # 로그 출력 차별화
                if result['status'] == 'SUCCESS':
                    logger.info(f"⚡ {ticker} 체결! | {agent_id} : {action} {qty}주 @ {final_price}원 ({order_desc})")
                    
                    # 🔥 [추가됨 2] 거래 성공 시 커뮤니티 댓글 작성
                    post_comment(db, agent_id, ticker, action, company.name)

                else:
                    logger.info(f"🕒 {ticker} 호가등록 | {agent_id} : {action} {qty}주 @ {final_price}원 (대기중)")

        except Exception as e:
            logger.error(f"❌ {agent_id} 거래 중 에러: {e}")

# ------------------------------------------------------------------
# 3. 메인 시뮬레이션 루프 (전 종목 거래 개방)
# ------------------------------------------------------------------
async def run_simulation_loop():
    logger.info("🚀 [Agent Society] 사회적 상호작용 마켓 시작 (전 종목 거래 개방)")
    
    while True:
        try:
            with SessionLocal() as db:
                all_companies = db.query(DBCompany).all()
                all_tickers = [c.ticker for c in all_companies] 
                
                # 1. 마켓 메이커 활동
                run_global_market_maker(db, all_tickers)
                
                # 2. 거래에 참여할 에이전트 선별
                all_agents = [a.agent_id for a in db.query(DBAgent.agent_id).all() if a.agent_id != "MARKET_MAKER"]

            # 매 턴마다 30명 랜덤 선발
            if len(all_agents) > 40:
                active_agents = random.sample(all_agents, k=30)
            else:
                active_agents = all_agents 
            
            tasks = []
            for agent_id in active_agents:
                my_ticker = random.choice(all_tickers) 
                tasks.append(run_agent_trade(agent_id, my_ticker))
            
            # 30명 동시 거래 실행
            await asyncio.gather(*tasks)
            
            await asyncio.sleep(1)

        except Exception as e:
            logger.error(f"🚨 메인 루프 치명적 에러: {e}")
            await asyncio.sleep(5)

if __name__ == "__main__":
    asyncio.run(run_simulation_loop()) 