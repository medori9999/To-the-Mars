import os
import json
import random
from openai import AsyncAzureOpenAI
from dotenv import load_dotenv
from domain_models import AgentState

load_dotenv()

client = AsyncAzureOpenAI(
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT")
)
AGENT_MODEL = os.getenv("MODEL_AGENT", "gpt-4o-mini") 

# [ASFM 논문 Appendix A.1 기반] 페르소나 정의
def get_agent_persona(agent_name):
    try:
        parts = agent_name.split('_')
        idx = int(parts[-1]) if len(parts) > 1 and parts[-1].isdigit() else random.randint(0, 99)
    except:
        idx = random.randint(0, 99)

    mod = idx % 10
    if mod < 4: 
        return "Value Investor (가치 투자자)", \
               "기업의 펀더멘탈과 내재 가치를 믿습니다. 저평가 시 매수하고, 단기 등락에 흔들리지 않는 뚝심이 있습니다."
    elif mod < 6: 
        return "Institutional Investor (기관 투자자)", \
               "철저한 리스크 관리와 포트폴리오 안정을 추구합니다. 불확실성을 싫어하며, 근거 없는 급등에는 참여하지 않습니다."
    elif mod < 8: 
        return "Contrarian Investor (역발상 투자자)", \
               "대중과 반대로 행동합니다. 남들이 환호할 때 팔고, 공포에 질려 던질 때 줍습니다. 군중 심리를 역이용합니다."
    else: 
        return "Aggressive Speculator (공격적 투기꾼)", \
               "모멘텀과 추세를 추종합니다. 오르는 말에 올라타는 것을 즐기며, 하이 리스크 하이 리턴을 추구합니다."

# [AgentSociety 논문 핵심] 흐름(Stream)과 상호작용(Interaction)이 추가된 뇌
async def agent_society_think(
    agent_name, 
    agent_state: AgentState, 
    context_info, 
    current_price, 
    cash, 
    portfolio_qty=0, 
    avg_price=0,
    last_action_desc=None, # [Stream] 직전 행동과 생각 (기억)
    market_sentiment=None  # [Interaction] 시장 분위기 (사회적 압력)
):
    agent_type, strategy_prompt = get_agent_persona(agent_name)

    # 1. 자산 상태 분석 (Needs & Constraints)
    valuation = int(portfolio_qty * current_price)
    
    # 수익률 계산 및 심리 상태 파악
    status_msg = "보유 주식 없음"
    if portfolio_qty > 0 and avg_price > 0:
        roi = ((current_price - avg_price) / avg_price) * 100
        roi_str = f"{roi:+.2f}%"
        if roi > 0: status_msg = f"🟢 수익 중 ({roi_str}) - 익절 욕구 발생 가능"
        else: status_msg = f"🔴 손실 중 ({roi_str}) - 본전 심리/공포 발생 가능"

    # 2. [Stream Memory] 기억 복원
    # 논문: 에이전트는 과거의 자신과 일관성을 유지하거나, 실수를 수정하려 함
    memory_context = "최근 거래 기록 없음."
    if last_action_desc:
        memory_context = f"📜 [직전 기억]: 당신은 지난번에 '{last_action_desc}'라고 생각하고 행동했습니다. 이 판단이 맞았나요? 아니면 후회되나요?"

    # 3. [Social Interaction] 사회적 압력 주입
    # 논문: 에이전트는 고립된 존재가 아니라 사회적 신호(Social Signals)에 반응함
    social_context = "시장 분위기 파악 불가."
    if market_sentiment:
        social_context = f"👥 [시장 분위기]: 현재 시장은 '{market_sentiment}' 상태입니다. 남들이 이렇게 행동하고 있습니다."

    # 4. 시스템 프롬프트 구성
    system_prompt = f"""
    당신은 '{agent_name}' ({agent_type})입니다.
    
    [당신의 투자 철학]
    {strategy_prompt}
    
    [행동 원칙 - Human Simulation]
    1. **흐름(Stream):** 당신의 과거 기억(직전 판단)과 현재 상황을 연결해서 생각하세요. 고집을 부릴지, 반성할지 결정하세요.
    2. **상호작용(Interaction):** 시장 분위기(남들의 행동)를 무시하지 마세요. 휩쓸릴지(FOMO), 비웃을지(역발상) 결정하세요.
    3. **감정(Emotion):** 기계처럼 굴지 마세요. 수익엔 탐욕을, 손실엔 공포를 느끼는 '사람'처럼 행동하세요.
    """
    
    # 5. 유저 프롬프트 구성 (모든 맥락 통합)
    user_prompt = f"""
    [현재 시장 데이터]
    - 종목 현재가: {int(current_price):,}원
    - 최신 뉴스: {context_info}
    - {social_context}
    
    [당신의 상태]
    - 현금: {int(cash):,}원
    - 주식: {portfolio_qty}주 (평단 {int(avg_price):,}원)
    - 상태: {status_msg}
    - {memory_context}
    
    위의 [기억]과 [사회적 분위기]를 고려하여 결정을 내리세요.
    응답은 오직 JSON 형식만 가능합니다.
    {{
        "thought_process": "과거 기억과 시장 분위기를 언급하며 의사결정 이유 서술 (한 문장)",
        "action": "BUY" 또는 "SELL" 또는 "HOLD",
        "price": (희망 가격, 정수),
        "quantity": (수량, 정수)
    }}
    """

    try:
        response = await client.chat.completions.create(
            model=AGENT_MODEL,
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0.9, # 사람 같은 예측 불가능성(변덕)을 위해 약간 높임
            response_format={"type": "json_object"},
            max_tokens=300
        )
        content = response.choices[0].message.content.replace("```json", "").replace("```", "").strip()
        decision = json.loads(content)
        
        # --- 안전장치 (Safety Rails) ---
        action = decision.get("action", "HOLD").upper()
        raw_price = int(decision.get("price", current_price))
        qty = int(decision.get("quantity", 0))

        # 가격 캡 (현재가 ±15%)
        if raw_price <= 0: raw_price = int(current_price)
        price = max(int(current_price * 0.85), min(raw_price, int(current_price * 1.15)))
        decision["price"] = price

        # 수량 검증
        if action == "BUY":
            max_buyable = int(cash // price)
            if max_buyable == 0: 
                return {"action": "HOLD", "quantity": 0, "price": price, "thought_process": "현금 부족으로 관망"}
            decision["quantity"] = min(qty, max_buyable)
        
        elif action == "SELL":
            if portfolio_qty == 0:
                return {"action": "HOLD", "quantity": 0, "price": price, "thought_process": "보유 주식 없음"}
            decision["quantity"] = min(qty, portfolio_qty)

        if action != "HOLD" and decision["quantity"] <= 0:
             return {"action": "HOLD", "quantity": 0, "price": price, "thought_process": "수량 0으로 인한 관망"}

        return decision

    except Exception as e:
        print(f"❌ {agent_name} 뇌정지: {e}")
        return {"action": "HOLD", "quantity": 0, "price": int(current_price), "thought_process": "시스템 오류"}