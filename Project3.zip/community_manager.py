# community_manager.py (새로 만들기)

import random
from sqlalchemy.orm import Session
from database import DBDiscussion
from datetime import datetime

# 📜 매수했을 때 (희망회로)
BULL_COMMENTS = [
    "🚀 {name} 화성 갈끄니까~ 꽉 잡아!",
    "💎 역시 {name}은(는) 신이야. 믿고 있었다구!",
    "📈 지금 안 사면 바보 아님? ㅋㅋㅋ",
    "오늘 저녁은 치킨이다!! 🍗",
    "영차 영차! 구조대 출발합니다~",
    "이거 10만전자 갑니다. 반박 안 받음.",
    "나만 아니면 돼~~ ㅋㅋㅋㅋ",
    "풀매수 완료. 인생 걸었다."
]

# 📉 매도했을 때 (공포/비난)
BEAR_COMMENTS = [
    "💧 {name} 돔황챠!!!",
    "한강 물 따뜻하냐...?",
    "📉 아니 실적 좋다며 왜 떨어지는데 ㅡㅡ",
    "설거지 당했네 아오...",
    "구조대 언제 오나요? 3층에 사람 있어요!!",
    "주포 형님들 제발 살려주세요 ㅠㅠ",
    "내가 사니까 떨어지네 과학이다 과학 🧪",
    "손절 쳤습니다. 다신 안 쳐다봅니다."
]

def post_comment(db: Session, agent_id: str, ticker: str, action: str, company_name: str):
    # 🎲 20% 확률로만 글을 씀 (너무 많이 쓰면 DB 터짐)
    if random.random() > 0.2:
        return

    content = ""
    sentiment = ""

    if action == "BUY":
        template = random.choice(BULL_COMMENTS)
        content = template.format(name=company_name)
        sentiment = "BULL"
    elif action == "SELL":
        template = random.choice(BEAR_COMMENTS)
        content = template.format(name=company_name)
        sentiment = "BEAR"
    else:
        return

    # DB에 저장
    new_post = DBDiscussion(
        ticker=ticker,
        agent_id=agent_id,
        content=content,
        sentiment=sentiment,
        created_at=datetime.utcnow()
    )
    db.add(new_post)
    db.commit()
    
    print(f"💬 [댓글] {agent_id}: {content}")