from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import desc, asc
from database import SessionLocal, DBCompany, DBTrade, DBNews, DBAgent, DBDiscussion
import uvicorn

app = FastAPI()

# CORS 설정
origins = [
    "http://localhost:3000",
    "http://127.0.0.1:3000",
    "http://localhost:5173",
    "http://127.0.0.1:5173",
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 1. 기업 목록 조회 (등락폭 계산 로직 수정됨)
@app.get("/api/companies")
def get_companies():
    db = SessionLocal()
    companies = db.query(DBCompany).all()
    
    result = []
    for comp in companies:
        # [수정] 등락률 계산: '직전 거래'가 아니라 '맨 처음 거래(시가)'와 비교해야 누적 등락률이 보임
        # 가장 오래된 거래(시가 대용) 찾기
        first_trade = db.query(DBTrade).filter(DBTrade.ticker == comp.ticker).order_by(asc(DBTrade.timestamp)).first()
        # 가장 최근 거래(현재가)
        last_trade = db.query(DBTrade).filter(DBTrade.ticker == comp.ticker).order_by(desc(DBTrade.timestamp)).first()
        
        change_amount = 0
        change_rate = 0
        
        # 거래 내역이 존재하면 계산
        if first_trade and last_trade and first_trade.price > 0:
            start_price = first_trade.price
            curr_price = last_trade.price
            
            change_amount = curr_price - start_price
            change_rate = (change_amount / start_price) * 100
        
        result.append({
            "ticker": comp.ticker,
            "name": comp.name,
            "sector": comp.sector,
            "current_price": comp.current_price,
            "change_amount": change_amount,
            "change_rate": round(change_rate, 2) # 소수점 2자리
        })
        
    db.close()
    return result

# 2. 특정 기업 차트 데이터 (데이터 개수 대폭 증가)
@app.get("/api/chart/{ticker}")
def get_chart(ticker: str, limit: int = 3000): # [수정] 기본값을 100 -> 3000으로 변경, 파라미터로 조절 가능하게 함
    db = SessionLocal()
    # 최근 거래 내역을 limit 만큼 가져옴 (데이터가 많아야 캔들이 형성됨)
    trades = db.query(DBTrade).filter(DBTrade.ticker == ticker).order_by(desc(DBTrade.timestamp)).limit(limit).all()
    db.close()
    # 시간순 정렬 (과거 -> 현재)
    return [{"time": t.timestamp, "price": t.price} for t in trades][::-1]

# 3. 뉴스 가져오기
@app.get("/api/news/{company_name}")
def get_news(company_name: str):
    db = SessionLocal()
    news_list = db.query(DBNews).filter(DBNews.company_name == company_name).order_by(desc(DBNews.id)).limit(5).all()
    db.close()
    return news_list

# 4. 부자 랭킹
@app.get("/api/rank")
def get_rank():
    db = SessionLocal()
    agents = db.query(DBAgent).all()
    rich_list = []
    for ag in agents:
        if ag.agent_id == "MARKET_MAKER": continue
        stock_val = 0
        for tik, qty in ag.portfolio.items():
            c = db.query(DBCompany).filter(DBCompany.ticker == tik).first()
            if c: stock_val += qty * c.current_price
        rich_list.append({
            "agent_id": ag.agent_id,
            "total_asset": ag.cash_balance + stock_val
        })
    db.close()
    return sorted(rich_list, key=lambda x: x["total_asset"], reverse=True)[:10]

# 5. 커뮤니티 글 조회
@app.get("/api/community/{ticker}")
def get_community_posts(ticker: str):
    db = SessionLocal()
    posts = db.query(DBDiscussion).filter(DBDiscussion.ticker == ticker).order_by(desc(DBDiscussion.id)).limit(20).all()
    db.close()
    return [{
        "id": p.id,
        "author": p.agent_id,
        "content": p.content,
        "sentiment": p.sentiment,
        "time": p.created_at.strftime("%H:%M:%S")
    } for p in posts]

if __name__ == "__main__":
    uvicorn.run("api:app", host="0.0.0.0", port=8000, reload=True)